import { z } from "zod";

export const gameModes = [
  "overall",
  "ltm",
  "vanilla",
  "uhc",
  "pot",
  "nethop",
  "smp",
  "sword",
  "axe",
  "mace",
] as const;

export type GameMode = (typeof gameModes)[number];

export const tierLevels = ["HT1", "HT2", "HT3", "HT4", "LT1", "LT2", "LT3", "LT4"] as const;
export type TierLevel = (typeof tierLevels)[number] | "-";

export const regions = ["NA", "EU", "AS", "SA", "OCE"] as const;
export type Region = (typeof regions)[number];

export const combatTitles = [
  "Combat Grandmaster",
  "Combat Master",
  "Combat Ace",
  "Combat Expert",
  "Combat Specialist",
  "Combat Warrior",
  "Combat Fighter",
] as const;
export type CombatTitle = (typeof combatTitles)[number];

export interface PlayerTiers {
  vanilla?: string;
  uhc?: string;
  pot?: string;
  nethop?: string;
  smp?: string;
  sword?: string;
  axe?: string;
  mace?: string;
}

export interface Player {
  id: string;
  username: string;
  region: Region;
  points: number;
  title: CombatTitle;
  tiers: PlayerTiers;
  skinUrl?: string;
}

export interface RankedPlayer extends Player {
  rank: number;
}

export const playerSchema = z.object({
  id: z.string(),
  username: z.string(),
  region: z.enum(regions),
  points: z.number(),
  title: z.enum(combatTitles),
  tiers: z.object({
    vanilla: z.string().optional(),
    uhc: z.string().optional(),
    pot: z.string().optional(),
    nethop: z.string().optional(),
    smp: z.string().optional(),
    sword: z.string().optional(),
    axe: z.string().optional(),
    mace: z.string().optional(),
  }),
  skinUrl: z.string().optional(),
});

export type InsertPlayer = z.infer<typeof playerSchema>;

export const gameModeInfo: Record<GameMode, { name: string; icon: string }> = {
  overall: { name: "Overall", icon: "Trophy" },
  ltm: { name: "LTMs", icon: "Gamepad2" },
  vanilla: { name: "Vanilla", icon: "Leaf" },
  uhc: { name: "UHC", icon: "Heart" },
  pot: { name: "Pot", icon: "FlaskConical" },
  nethop: { name: "NethOP", icon: "Flame" },
  smp: { name: "SMP", icon: "Pickaxe" },
  sword: { name: "Sword", icon: "Sword" },
  axe: { name: "Axe", icon: "Axe" },
  mace: { name: "Mace", icon: "Hammer" },
};

export { users, insertUserSchema, type InsertUser, type User } from "./user-schema";
