import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import type { RankedPlayer, GameMode } from "@shared/schema";
import { GameModeNav } from "@/components/game-mode-nav";
import { LeaderboardHeader } from "@/components/leaderboard-header";
import { PlayerCard } from "@/components/player-card";
import { LeaderboardSkeleton } from "@/components/leaderboard-skeleton";
import { EmptyState } from "@/components/empty-state";

export default function RankingsPage() {
  const [activeMode, setActiveMode] = useState<GameMode>("overall");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: players, isLoading, error } = useQuery<RankedPlayer[]>({
    queryKey: ["/api/rankings", activeMode],
  });

  const filteredPlayers = useMemo(() => {
    if (!players) return [];
    if (!searchQuery.trim()) return players;
    
    const query = searchQuery.toLowerCase();
    return players.filter((player) =>
      player.username.toLowerCase().includes(query)
    );
  }, [players, searchQuery]);

  return (
    <div className="min-h-screen bg-background" data-testid="page-rankings">
      <LeaderboardHeader 
        searchQuery={searchQuery} 
        onSearchChange={setSearchQuery} 
      />
      
      <GameModeNav 
        activeMode={activeMode} 
        onModeChange={setActiveMode} 
      />

      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold" data-testid="text-mode-title">
            {activeMode.charAt(0).toUpperCase() + activeMode.slice(1)} Rankings
          </h2>
          {players && (
            <span className="text-sm text-muted-foreground" data-testid="text-player-count">
              {filteredPlayers.length} player{filteredPlayers.length !== 1 ? "s" : ""}
            </span>
          )}
        </div>

        {isLoading && <LeaderboardSkeleton />}

        {error && (
          <div className="text-center py-16" data-testid="error-state">
            <p className="text-destructive">Failed to load rankings. Please try again.</p>
          </div>
        )}

        {!isLoading && !error && filteredPlayers.length === 0 && searchQuery && (
          <EmptyState type="no-results" searchQuery={searchQuery} />
        )}

        {!isLoading && !error && players?.length === 0 && !searchQuery && (
          <EmptyState type="no-players" />
        )}

        {!isLoading && !error && filteredPlayers.length > 0 && (
          <div className="space-y-3" data-testid="leaderboard-list">
            {filteredPlayers.map((player) => (
              <PlayerCard key={player.id} player={player} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
