import { cn } from "@/lib/utils";
import {
  Leaf,
  Heart,
  FlaskConical,
  Flame,
  Pickaxe,
  Sword,
  Axe,
  Hammer,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const gameModeIcons: Record<string, React.ComponentType<{ className?: string }>> = {
  vanilla: Leaf,
  uhc: Heart,
  pot: FlaskConical,
  nethop: Flame,
  smp: Pickaxe,
  sword: Sword,
  axe: Axe,
  mace: Hammer,
};

const gameModeNames: Record<string, string> = {
  vanilla: "Vanilla",
  uhc: "UHC",
  pot: "Pot",
  nethop: "NethOP",
  smp: "SMP",
  sword: "Sword",
  axe: "Axe",
  mace: "Mace",
};

interface TierBadgeProps {
  gameMode: string;
  tier: string;
  size?: "sm" | "md";
}

export function TierBadge({ gameMode, tier, size = "sm" }: TierBadgeProps) {
  const Icon = gameModeIcons[gameMode];
  const modeName = gameModeNames[gameMode] || gameMode;
  const isHighTier = tier.startsWith("HT");
  const isEmpty = tier === "-" || !tier;

  const sizeClasses = {
    sm: "h-5 w-auto min-w-[42px] px-1",
    md: "h-6 w-auto min-w-[52px] px-1.5",
  };

  const iconClasses = {
    sm: "h-3 w-3",
    md: "h-3.5 w-3.5",
  };

  const textClasses = {
    sm: "text-[10px]",
    md: "text-xs",
  };

  if (isEmpty) {
    return (
      <div 
        className={cn(
          "inline-flex items-center justify-center gap-0.5 rounded-full bg-muted/50 text-muted-foreground",
          sizeClasses[size]
        )}
        data-testid={`tier-badge-${gameMode}`}
      >
        {Icon && <Icon className={iconClasses[size]} />}
        <span className={cn("font-bold", textClasses[size])}>-</span>
      </div>
    );
  }

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div 
          className={cn(
            "inline-flex items-center justify-center gap-0.5 rounded-full",
            sizeClasses[size],
            isHighTier 
              ? "bg-amber-500/20 text-amber-400 border border-amber-500/30" 
              : "bg-sky-500/20 text-sky-400 border border-sky-500/30"
          )}
          data-testid={`tier-badge-${gameMode}`}
        >
          {Icon && <Icon className={iconClasses[size]} />}
          <span className={cn("font-bold", textClasses[size])}>{tier}</span>
        </div>
      </TooltipTrigger>
      <TooltipContent>
        <p>{modeName}: {tier}</p>
      </TooltipContent>
    </Tooltip>
  );
}
