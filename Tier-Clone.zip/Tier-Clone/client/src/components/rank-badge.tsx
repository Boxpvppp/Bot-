import { cn } from "@/lib/utils";

interface RankBadgeProps {
  rank: number;
}

export function RankBadge({ rank }: RankBadgeProps) {
  const getShimmerClass = () => {
    switch (rank) {
      case 1:
        return "shimmer-gold";
      case 2:
        return "shimmer-silver";
      case 3:
        return "shimmer-bronze";
      default:
        return "bg-muted";
    }
  };

  const getTextColor = () => {
    if (rank <= 3) {
      return "text-background font-black";
    }
    return "text-muted-foreground font-bold";
  };

  return (
    <div
      className={cn(
        "flex items-center justify-center rounded-md min-w-[48px] h-12",
        getShimmerClass()
      )}
      data-testid={`rank-badge-${rank}`}
    >
      <span className={cn("text-xl", getTextColor())}>
        #{rank}
      </span>
    </div>
  );
}
