import { Copy, Check, Server } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useState } from "react";

interface ServerInfoProps {
  serverIp: string;
  serverName?: string;
}

export function ServerInfo({ serverIp, serverName = "PvP Club" }: ServerInfoProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(serverIp);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className="p-4 flex items-center gap-4" data-testid="server-info-card">
      <div className="h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
        <Server className="h-6 w-6 text-primary" />
      </div>
      <div className="flex-1">
        <p className="text-sm text-muted-foreground">Server IP</p>
        <p className="font-mono font-bold text-lg" data-testid="text-server-ip">{serverIp}</p>
      </div>
      <Button
        variant="outline"
        size="icon"
        onClick={handleCopy}
        data-testid="button-copy-ip"
      >
        {copied ? (
          <Check className="h-4 w-4 text-primary" />
        ) : (
          <Copy className="h-4 w-4" />
        )}
      </Button>
    </Card>
  );
}
