import { cn } from "@/lib/utils";
import { Trophy, Medal, Star, Shield, Swords, Target, Crosshair } from "lucide-react";
import type { CombatTitle } from "@shared/schema";

const titleIcons: Record<CombatTitle, React.ComponentType<{ className?: string }>> = {
  "Combat Grandmaster": Trophy,
  "Combat Master": Medal,
  "Combat Ace": Star,
  "Combat Expert": Shield,
  "Combat Specialist": Swords,
  "Combat Warrior": Target,
  "Combat Fighter": Crosshair,
};

const titleColors: Record<CombatTitle, string> = {
  "Combat Grandmaster": "text-amber-400 bg-amber-500/20",
  "Combat Master": "text-purple-400 bg-purple-500/20",
  "Combat Ace": "text-sky-400 bg-sky-500/20",
  "Combat Expert": "text-emerald-400 bg-emerald-500/20",
  "Combat Specialist": "text-rose-400 bg-rose-500/20",
  "Combat Warrior": "text-orange-400 bg-orange-500/20",
  "Combat Fighter": "text-slate-400 bg-slate-500/20",
};

interface CombatTitleBadgeProps {
  title: CombatTitle;
  points: number;
}

export function CombatTitleBadge({ title, points }: CombatTitleBadgeProps) {
  const Icon = titleIcons[title];
  const colorClass = titleColors[title];

  return (
    <div 
      className={cn(
        "inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md text-xs font-medium",
        colorClass
      )}
      data-testid="badge-combat-title"
    >
      {Icon && <Icon className="h-3 w-3" />}
      <span>{title}</span>
      <span className="opacity-70">({points} pts)</span>
    </div>
  );
}
