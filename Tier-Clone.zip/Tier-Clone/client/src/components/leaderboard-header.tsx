import { SearchBar } from "./search-bar";
import { ServerInfo } from "./server-info";
import { ThemeToggle } from "./theme-toggle";
import { Trophy } from "lucide-react";

interface LeaderboardHeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export function LeaderboardHeader({ searchQuery, onSearchChange }: LeaderboardHeaderProps) {
  return (
    <header className="border-b border-border bg-card" data-testid="header-main">
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
              <Trophy className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight" data-testid="text-site-title">MCTiers</h1>
              <p className="text-sm text-muted-foreground">Minecraft PvP Rankings</p>
            </div>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <SearchBar value={searchQuery} onChange={onSearchChange} />
            <ThemeToggle />
          </div>
        </div>
        <div className="max-w-xs">
          <ServerInfo serverIp="mcpvp.club" />
        </div>
      </div>
    </header>
  );
}
