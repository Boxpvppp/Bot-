import type { RankedPlayer } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { RankBadge } from "./rank-badge";
import { PlayerAvatar } from "./player-avatar";
import { CombatTitleBadge } from "./combat-title";
import { TierBadge } from "./tier-badge";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface PlayerCardProps {
  player: RankedPlayer;
}

const tierOrder = ["vanilla", "pot", "smp", "mace", "sword", "nethop", "axe", "uhc"] as const;

export function PlayerCard({ player }: PlayerCardProps) {
  const isTopThree = player.rank <= 3;

  return (
    <Card 
      className={cn(
        "p-4 hover-elevate transition-colors",
        isTopThree && "border-primary/30"
      )}
      data-testid={`player-card-${player.id}`}
    >
      <div className="flex items-center gap-4">
        <RankBadge rank={player.rank} />
        
        <PlayerAvatar username={player.username} skinUrl={player.skinUrl} />
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h3 
              className="font-bold text-lg truncate"
              data-testid={`text-username-${player.id}`}
            >
              {player.username}
            </h3>
            <Badge variant="outline" size="sm" data-testid={`badge-region-${player.id}`}>
              {player.region}
            </Badge>
          </div>
          <CombatTitleBadge title={player.title} points={player.points} />
        </div>

        <div className="hidden md:flex items-center gap-1 flex-wrap justify-end max-w-[320px]">
          {tierOrder.map((mode) => {
            const tier = player.tiers[mode as keyof typeof player.tiers];
            return (
              <TierBadge 
                key={mode} 
                gameMode={mode} 
                tier={tier || "-"} 
              />
            );
          })}
        </div>
      </div>

      <div className="md:hidden mt-3 pt-3 border-t border-border">
        <div className="flex items-center gap-1 flex-wrap">
          {tierOrder.map((mode) => {
            const tier = player.tiers[mode as keyof typeof player.tiers];
            return (
              <TierBadge 
                key={mode} 
                gameMode={mode} 
                tier={tier || "-"} 
              />
            );
          })}
        </div>
      </div>
    </Card>
  );
}
