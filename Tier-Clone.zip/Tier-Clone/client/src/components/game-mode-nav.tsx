import { type GameMode, gameModeInfo } from "@shared/schema";
import {
  Trophy,
  Gamepad2,
  Leaf,
  Heart,
  FlaskConical,
  Flame,
  Pickaxe,
  Sword,
  Axe,
  Hammer,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Trophy,
  Gamepad2,
  Leaf,
  Heart,
  FlaskConical,
  Flame,
  Pickaxe,
  Sword,
  Axe,
  Hammer,
};

interface GameModeNavProps {
  activeMode: GameMode;
  onModeChange: (mode: GameMode) => void;
}

export function GameModeNav({ activeMode, onModeChange }: GameModeNavProps) {
  const modes = Object.entries(gameModeInfo) as [GameMode, { name: string; icon: string }][];

  return (
    <nav 
      className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60"
      data-testid="nav-game-modes"
    >
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="grid grid-cols-5 md:grid-cols-10 gap-2">
          {modes.map(([mode, { name, icon }]) => {
            const Icon = iconMap[icon];
            const isActive = mode === activeMode;

            return (
              <Card
                key={mode}
                onClick={() => onModeChange(mode)}
                className={cn(
                  "flex flex-col items-center justify-center gap-1 p-2 cursor-pointer transition-all",
                  "hover-elevate active-elevate-2",
                  isActive
                    ? "border-primary bg-primary/10 text-primary"
                    : "text-muted-foreground border-transparent bg-card/50"
                )}
                data-testid={`button-mode-${mode}`}
              >
                {Icon && <Icon className="h-5 w-5" />}
                <span className="text-[10px] md:text-xs font-medium whitespace-nowrap">{name}</span>
              </Card>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
