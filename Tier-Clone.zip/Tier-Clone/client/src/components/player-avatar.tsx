import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "lucide-react";

interface PlayerAvatarProps {
  username: string;
  skinUrl?: string;
  size?: "sm" | "md" | "lg";
}

export function PlayerAvatar({ username, skinUrl, size = "md" }: PlayerAvatarProps) {
  const sizeClasses = {
    sm: "h-8 w-8",
    md: "h-12 w-12",
    lg: "h-16 w-16",
  };

  const iconSizes = {
    sm: "h-4 w-4",
    md: "h-6 w-6",
    lg: "h-8 w-8",
  };

  const fallbackText = username.slice(0, 2).toUpperCase();

  return (
    <Avatar className={sizeClasses[size]} data-testid={`avatar-${username}`}>
      <AvatarImage 
        src={skinUrl || `https://mc-heads.net/avatar/${username}/64`} 
        alt={`${username}'s skin`}
      />
      <AvatarFallback className="bg-muted">
        {skinUrl ? (
          <User className={iconSizes[size]} />
        ) : (
          <span className="text-xs font-medium">{fallbackText}</span>
        )}
      </AvatarFallback>
    </Avatar>
  );
}
