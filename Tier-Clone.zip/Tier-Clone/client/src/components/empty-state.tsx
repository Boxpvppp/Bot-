import { SearchX, Users } from "lucide-react";

interface EmptyStateProps {
  type: "no-results" | "no-players";
  searchQuery?: string;
}

export function EmptyState({ type, searchQuery }: EmptyStateProps) {
  if (type === "no-results") {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center" data-testid="empty-state-no-results">
        <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
          <SearchX className="h-8 w-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold mb-1">No players found</h3>
        <p className="text-muted-foreground text-sm">
          No players match "{searchQuery}". Try a different search term.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center py-16 text-center" data-testid="empty-state-no-players">
      <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
        <Users className="h-8 w-8 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-semibold mb-1">No ranked players yet</h3>
      <p className="text-muted-foreground text-sm">
        Rankings will appear here once players start competing.
      </p>
    </div>
  );
}
