import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export function LeaderboardSkeleton() {
  return (
    <div className="space-y-3" data-testid="skeleton-leaderboard">
      {Array.from({ length: 10 }).map((_, i) => (
        <Card key={i} className="p-4">
          <div className="flex items-center gap-4">
            <Skeleton className="h-12 w-12 rounded-md" />
            <Skeleton className="h-12 w-12 rounded-full" />
            <div className="flex-1 space-y-2">
              <Skeleton className="h-5 w-32" />
              <Skeleton className="h-4 w-48" />
            </div>
            <div className="hidden md:flex gap-1">
              {Array.from({ length: 8 }).map((_, j) => (
                <Skeleton key={j} className="h-6 w-12 rounded-md" />
              ))}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
