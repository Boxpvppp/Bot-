import type { Player, RankedPlayer, GameMode, PlayerTiers } from "@shared/schema";

export interface IStorage {
  getPlayers(): Promise<Player[]>;
  getPlayerById(id: string): Promise<Player | undefined>;
  getPlayerByUsername(username: string): Promise<Player | undefined>;
  getRankings(mode: GameMode): Promise<RankedPlayer[]>;
  searchPlayers(query: string): Promise<Player[]>;
}

const mockPlayers: Player[] = [
  {
    id: "player-001-marlowww",
    username: "Marlowww",
    region: "NA",
    points: 420,
    title: "Combat Grandmaster",
    tiers: { vanilla: "HT1", pot: "HT1", smp: "HT1", mace: "LT1", sword: "LT1", nethop: "LT1", axe: "LT1", uhc: "LT1" },
  },
  {
    id: "player-002-itzrealme",
    username: "ItzRealMe",
    region: "NA",
    points: 330,
    title: "Combat Master",
    tiers: { pot: "HT1", vanilla: "HT1", nethop: "HT1", smp: "HT1", sword: "HT2", uhc: "LT2", axe: "LT2", mace: "LT2" },
  },
  {
    id: "player-003-swight",
    username: "Swight",
    region: "NA",
    points: 290,
    title: "Combat Master",
    tiers: { uhc: "HT1", axe: "HT1", nethop: "HT2", pot: "LT2", vanilla: "HT3", mace: "HT3", smp: "HT1", sword: "LT2" },
  },
  {
    id: "player-004-coldified",
    username: "coldified",
    region: "EU",
    points: 256,
    title: "Combat Master",
    tiers: { uhc: "HT2", mace: "HT2", axe: "HT2", pot: "HT2", sword: "LT2", nethop: "LT2", vanilla: "LT3", smp: "HT1" },
  },
  {
    id: "player-005-kylaz",
    username: "Kylaz",
    region: "NA",
    points: 222,
    title: "Combat Ace",
    tiers: { sword: "HT1", pot: "LT1", uhc: "LT3", vanilla: "LT3", smp: "LT3", nethop: "HT1", axe: "LT2" },
  },
  {
    id: "player-006-blvckwlf",
    username: "BlvckWlf",
    region: "EU",
    points: 206,
    title: "Combat Ace",
    tiers: { sword: "HT3", mace: "HT3", nethop: "LT3", vanilla: "LT3", uhc: "HT1", smp: "HT1", axe: "HT2", pot: "LT2" },
  },
  {
    id: "player-007-janekv",
    username: "janekv",
    region: "EU",
    points: 199,
    title: "Combat Ace",
    tiers: { sword: "LT2", nethop: "LT2", uhc: "HT3", axe: "HT3", vanilla: "HT4", pot: "HT1", smp: "LT1" },
  },
  {
    id: "player-008-lurrn",
    username: "Lurrn",
    region: "EU",
    points: 186,
    title: "Combat Ace",
    tiers: { uhc: "LT3", axe: "LT4", pot: "HT1", nethop: "HT1", vanilla: "HT2", sword: "LT2" },
  },
  {
    id: "player-009-ymiau",
    username: "yMiau",
    region: "EU",
    points: 177,
    title: "Combat Ace",
    tiers: { uhc: "LT1", nethop: "LT3", pot: "LT3", sword: "LT3", mace: "LT3", vanilla: "LT3", smp: "LT1", axe: "HT2" },
  },
  {
    id: "player-010-ninorc15",
    username: "ninorc15",
    region: "EU",
    points: 171,
    title: "Combat Ace",
    tiers: { sword: "LT2", axe: "LT2", pot: "LT2", nethop: "HT3", mace: "HT3", vanilla: "LT3", smp: "LT1", uhc: "HT2" },
  },
  {
    id: "player-011-xstrafez",
    username: "xStrafez",
    region: "NA",
    points: 165,
    title: "Combat Expert",
    tiers: { vanilla: "HT2", pot: "HT2", smp: "LT2", sword: "LT2", axe: "LT3", uhc: "LT3", nethop: "LT3" },
  },
  {
    id: "player-012-dragonslayerx",
    username: "DragonSlayerX",
    region: "AS",
    points: 158,
    title: "Combat Expert",
    tiers: { uhc: "HT2", sword: "HT2", axe: "LT2", pot: "LT3", vanilla: "LT3", smp: "LT2", mace: "LT3" },
  },
  {
    id: "player-013-pvpking99",
    username: "PvPKing99",
    region: "NA",
    points: 152,
    title: "Combat Expert",
    tiers: { pot: "HT2", nethop: "HT2", vanilla: "LT2", sword: "LT3", axe: "LT3", uhc: "LT3", smp: "LT2" },
  },
  {
    id: "player-014-shadowblade",
    username: "ShadowBlade",
    region: "EU",
    points: 145,
    title: "Combat Expert",
    tiers: { sword: "HT1", vanilla: "LT3", pot: "LT3", nethop: "LT4", axe: "LT4", uhc: "LT3" },
  },
  {
    id: "player-015-crystalwarrior",
    username: "CrystalWarrior",
    region: "SA",
    points: 138,
    title: "Combat Specialist",
    tiers: { mace: "HT2", smp: "HT2", vanilla: "LT2", pot: "LT3", sword: "LT3", axe: "LT4" },
  },
  {
    id: "player-016-nighthawk",
    username: "NightHawk",
    region: "OCE",
    points: 131,
    title: "Combat Specialist",
    tiers: { axe: "HT1", uhc: "LT2", sword: "LT3", vanilla: "LT4", pot: "LT4", nethop: "LT4" },
  },
  {
    id: "player-017-frostbyte",
    username: "FrostByte",
    region: "EU",
    points: 125,
    title: "Combat Specialist",
    tiers: { nethop: "HT2", pot: "HT3", vanilla: "LT3", sword: "LT3", axe: "LT4", smp: "LT2" },
  },
  {
    id: "player-018-thunderstrike",
    username: "ThunderStrike",
    region: "NA",
    points: 118,
    title: "Combat Specialist",
    tiers: { vanilla: "HT3", smp: "HT3", pot: "LT2", sword: "LT3", uhc: "LT4", axe: "LT4" },
  },
  {
    id: "player-019-blazemaster",
    username: "BlazeMaster",
    region: "AS",
    points: 112,
    title: "Combat Warrior",
    tiers: { nethop: "HT3", pot: "LT2", vanilla: "LT3", sword: "LT4", axe: "LT4", uhc: "LT4" },
  },
  {
    id: "player-020-ironfist",
    username: "IronFist",
    region: "EU",
    points: 105,
    title: "Combat Warrior",
    tiers: { mace: "HT3", axe: "LT2", sword: "LT3", vanilla: "LT4", pot: "LT4", smp: "LT3" },
  },
  {
    id: "player-021-phantomx",
    username: "PhantomX",
    region: "NA",
    points: 98,
    title: "Combat Warrior",
    tiers: { smp: "HT2", vanilla: "LT3", pot: "LT4", sword: "LT4", uhc: "LT4" },
  },
  {
    id: "player-022-vortexplayer",
    username: "VortexPlayer",
    region: "SA",
    points: 92,
    title: "Combat Fighter",
    tiers: { pot: "HT4", vanilla: "LT3", sword: "LT4", axe: "LT4", nethop: "LT4" },
  },
  {
    id: "player-023-steelreaper",
    username: "SteelReaper",
    region: "EU",
    points: 85,
    title: "Combat Fighter",
    tiers: { sword: "HT4", axe: "LT3", vanilla: "LT4", pot: "LT4", uhc: "LT4" },
  },
  {
    id: "player-024-crimsonflame",
    username: "CrimsonFlame",
    region: "OCE",
    points: 78,
    title: "Combat Fighter",
    tiers: { nethop: "HT4", vanilla: "LT4", pot: "LT4", sword: "LT4" },
  },
  {
    id: "player-025-mysticarrow",
    username: "MysticArrow",
    region: "AS",
    points: 72,
    title: "Combat Fighter",
    tiers: { uhc: "LT3", vanilla: "LT4", pot: "LT4", sword: "LT4", axe: "LT4" },
  },
];

function getTierScore(tier: string | undefined): number {
  if (!tier || tier === "-") return 0;
  const tierMap: Record<string, number> = {
    "HT1": 100, "HT2": 85, "HT3": 70, "HT4": 55,
    "LT1": 45, "LT2": 35, "LT3": 25, "LT4": 15,
  };
  return tierMap[tier] || 0;
}

function sortByMode(players: Player[], mode: GameMode): RankedPlayer[] {
  let sorted: Player[];
  
  if (mode === "overall" || mode === "ltm") {
    sorted = [...players].sort((a, b) => b.points - a.points);
  } else {
    sorted = [...players].sort((a, b) => {
      const tierA = a.tiers[mode as keyof PlayerTiers];
      const tierB = b.tiers[mode as keyof PlayerTiers];
      const scoreA = getTierScore(tierA);
      const scoreB = getTierScore(tierB);
      if (scoreB !== scoreA) return scoreB - scoreA;
      return b.points - a.points;
    });
  }

  return sorted.map((player, index) => ({
    ...player,
    rank: index + 1,
  }));
}

export class MemStorage implements IStorage {
  private players: Map<string, Player>;

  constructor() {
    this.players = new Map();
    mockPlayers.forEach((player) => {
      this.players.set(player.id, player);
    });
  }

  async getPlayers(): Promise<Player[]> {
    return Array.from(this.players.values());
  }

  async getPlayerById(id: string): Promise<Player | undefined> {
    return this.players.get(id);
  }

  async getPlayerByUsername(username: string): Promise<Player | undefined> {
    return Array.from(this.players.values()).find(
      (player) => player.username.toLowerCase() === username.toLowerCase()
    );
  }

  async getRankings(mode: GameMode): Promise<RankedPlayer[]> {
    const players = Array.from(this.players.values());
    return sortByMode(players, mode);
  }

  async searchPlayers(query: string): Promise<Player[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.players.values()).filter(
      (player) => player.username.toLowerCase().includes(lowerQuery)
    );
  }
}

export const storage = new MemStorage();
