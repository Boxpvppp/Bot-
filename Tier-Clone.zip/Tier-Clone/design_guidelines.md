# MCTiers Design Guidelines

## Design Approach
**System-Based Design** using a modern data-focused framework suitable for gaming platforms. Drawing inspiration from competitive gaming leaderboards (League of Legends, Valorant) and data platforms like GitHub's dark mode. Priority: clarity, hierarchy, and quick data scanning.

## Core Design Elements

### Typography
- **Primary Font**: Inter or Roboto (via Google Fonts CDN)
- **Display/Headers**: 700 weight, uppercase for ranks and titles
- **Body Text**: 400-500 weight for player names and stats
- **Micro Text**: 400 weight, 12-14px for tier labels and metadata
- **Hierarchy**: Large rank numbers (text-4xl), medium player names (text-xl), small stats (text-sm)

### Layout System
**Spacing Primitives**: Tailwind units of 2, 4, 6, and 8
- Container max-width: `max-w-7xl`
- Section padding: `py-8` (mobile), `py-12` (desktop)
- Card spacing: `gap-4` for grids, `space-y-6` for lists
- Inline spacing: `px-4` to `px-6` for containers

### Component Library

**Navigation Bar**
- Horizontal scrollable game mode tabs with icons and labels
- Active state with underline indicator
- Sticky positioning during scroll
- Icon size: 24x24px, labels below icons

**Leaderboard Cards** (Primary Component)
- Rank badge: Large number with special shimmer SVG overlay for top 3
- Minecraft skin avatar: 64x64px placeholder image
- Player name: Bold, prominent typography
- Combat title: Badge with icon + title + points
- Region indicator: Small flag or text badge
- Tier badges grid: 8 small icons with tier labels (HT1, LT2, etc.)
- Hover state: subtle elevation increase

**Placement Badges**
- Top 3 positions: Gold (#FFD700), Silver (#C0C0C0), Bronze (#CD7F32) gradient backgrounds
- Shimmer effect: Animated diagonal gradient overlay (CSS animation)
- Rank 4+: Neutral gray background

**Tier Icons**
- Small circular or square badges (20x20px)
- Game mode icon with tier text overlay
- Color coding: High Tier (warm colors), Low Tier (cool colors)

**Search Bar**
- Full-width on mobile, max-w-md on desktop
- Icon prefix (search icon from Heroicons)
- Placeholder: "Search player..."

### Structure

**Hero Section** (Optional Compact Version)
- Server information box: Server IP, featured stats
- Logo placement (PvP Club or similar)
- Background: Subtle Minecraft-themed pattern or solid dark
- Height: 40vh max (not full viewport)

**Main Leaderboard**
- List-based layout (not excessive cards)
- Each player: horizontal card with left rank, center info, right tier badges
- Pagination or infinite scroll for 100+ players
- Alternating row backgrounds for scannability

**Navigation Tabs**
- Multi-column grid on desktop (3-4 columns)
- Single column stack on mobile
- Each tab: Icon + Label in clickable card

### Visual Principles
- **Gaming Dark Theme**: Deep backgrounds, bright accents for ranks/tiers
- **Data Density**: Compact information display without feeling cramped
- **Scannable Hierarchy**: Rank numbers and player names immediately visible
- **Competitive Feel**: Bold typography, clear winners/rankings emphasis
- **Minecraft Aesthetic**: Blocky/pixelated UI elements where appropriate

### Images
- **Minecraft Skins**: Use placeholder API (`https://mctiers.com/skin-404.avif` style) for player avatars
- **Tier Icons**: Small SVG icons for each game mode (vanilla, pot, uhc, sword, axe, mace, nethop, smp)
- **Placement Badges**: SVG shimmer overlays for top 3 ranks
- **Server Logo**: Featured in header/hero section
- **No large hero image**: This is data-first, not marketing

### Animation
Use sparingly:
- Shimmer effect on top 3 rank badges (subtle diagonal gradient sweep)
- Smooth tab transitions when switching game modes
- Hover elevation on player cards
- No complex scroll animations

### Responsive Behavior
- Desktop: Multi-column tier badge grids (4 columns)
- Tablet: 2-column tier grids
- Mobile: Single column, stack all elements vertically, horizontal scroll for navigation tabs